//
//  ViewController.swift
//  QRAR
//
//  Created by Jeff Cedilla on 8/21/17.
//  Copyright © 2017 spaghetticoder. All rights reserved.
//

import UIKit
import SceneKit
import ARKit

class QRViewController: UIViewController {
    
    var detector: CIDetector?
    var userNodes: [ARAnchor: SCNNode] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        configuration.isLightEstimationEnabled = true
        
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        sceneView.session.pause()
    }
    
    let sceneView: ARSCNView = {
        let sceneView = ARSCNView()
        sceneView.isUserInteractionEnabled = true
        sceneView.isMultipleTouchEnabled = true
        sceneView.allowsCameraControl = true
        sceneView.isOpaque = false
        sceneView.loops = true
        sceneView.backgroundColor = UIColor.white
        sceneView.showsStatistics = true
        sceneView.translatesAutoresizingMaskIntoConstraints = false
        sceneView.contentMode = .scaleToFill
        sceneView.clipsToBounds = true
        sceneView.debugOptions = [ARSCNDebugOptions.showFeaturePoints]
        
        sceneView.scene = SCNScene()
        
        return sceneView
    }()
    
    let sceneNode: SCNNode = {
        let node = SCNNode()
        return node
    }()

//    lazy var textNode: SCNNode = {
//        let scene = SCNScene()
//        let textNode = SCNText(string: "text", extrusionDepth: 1)
//        textNode.flatness = 0
//
//        let material = SCNMaterial()
//        material.isDoubleSided = true
//        material.normal.contents = UIColor.black
//        material.diffuse.contents = UIColor.black
//        material.specular.contents = UIColor.black
//        textNode.materials = [material]
//
//        let node = SCNNode(geometry: textNode)
//        scene.rootNode.childNodes.forEach { node.addChildNode($0) }
//        node.scale = .init(0.25, 0.25, 0.25)
//        node.position = .init(0, 0.1, 0)
//        return node
//    }()
    
}

//MARK: - Setup UI

extension QRViewController {

    private func setupViews() {

//        sceneView.scene = scene
//        sceneNode.geometry = sceneText
//        scene.rootNode.addChildNode(sceneNode)
        sceneView.delegate = self
        
        let recognizer = UITapGestureRecognizer(target: self, action: #selector(self.snapImage(_:)))
        recognizer.numberOfTapsRequired = 1
        sceneView.addGestureRecognizer(recognizer)

//        let textNode = SCNText(string: "a", extrusionDepth: 1)
//        textNode.flatness = 0
//
//        let material = SCNMaterial()
//        material.isDoubleSided = true
//        material.normal.contents = UIColor.black
//        material.diffuse.contents = UIColor.black
//        material.specular.contents = UIColor.black
//        textNode.materials = [material]
//
//        let node = SCNNode(geometry: textNode)
//        node.transform = SCNMatrix4MakeTranslation(transform.columns.3.x, transform.columns.3.y + 0.5, transform.columns.3.z)
//        node.scale = .init(0.25, 0.25, 0.25)
//        node.position = .init(0, 0.1, 0)
//
//        sceneView.scene.rootNode.addChildNode(node)
        
        view.addSubview(sceneView)
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[v0]|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": sceneView]))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[v0]|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": sceneView]))
    }
    
    private func makePlane(from anchor: ARPlaneAnchor) -> SCNNode {
        let plane = SCNPlane(width: CGFloat(anchor.extent.x), height: CGFloat(anchor.extent.z))
        let material = SCNMaterial()
        material.isDoubleSided = true
        material.diffuse.contents = UIColor.green.withAlphaComponent(0.25)
        plane.materials = [material]
        let node = SCNNode(geometry: plane)
        node.position = .init(anchor.center.x, 0, anchor.center.z)
        node.transform = SCNMatrix4MakeRotation(-Float.pi/2, 1, 0, 0)
        node.physicsBody = SCNPhysicsBody(type: .static, shape: SCNPhysicsShape(geometry: plane, options: [:]))
        return node
    }
    
    
}

    // MARK: - AR Delegate Methods
extension QRViewController: ARSCNViewDelegate {
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        if let planeAnchor = anchor as? ARPlaneAnchor {
            let planeNode = makePlane(from: planeAnchor)
            node.addChildNode(planeNode)
        }
        
        
        
        if let userNode = userNodes[anchor] {
            node.addChildNode(userNode)
            print("added a text node")
        }
        
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        if let planeAnchor = anchor as? ARPlaneAnchor {
            node.enumerateChildNodes { node, _ in node.removeFromParentNode() }
            let planeNode = makePlane(from: planeAnchor)
            node.addChildNode(planeNode)
        }
        
    }
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
}

