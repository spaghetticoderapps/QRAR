//
//  QRReader.swift
//  QRAR
//
//  Created by Jeff Cedilla on 8/21/17.
//  Copyright © 2017 spaghetticoder. All rights reserved.
//

import Foundation
import AVFoundation
import UIKit
import ARKit

extension QRViewController {
    
    @objc func snapImage(_ sender: UITapGestureRecognizer) {
        let snapshot = sceneView.snapshot()
        let ciImage = CIImage(image: snapshot)
        let decodedMessage = performQRCodeDetection(ciImage!)
        print("snapshot taken and decoded: \(decodedMessage)")
        
        let location = sender.location(in: sceneView)
        let normalizedPoint = CGPoint(x: location.x / sceneView.bounds.size.width,
                                      y: location.y / sceneView.bounds.size.height)
        
        let results = sceneView.session.currentFrame?.hitTest(normalizedPoint, types: [.estimatedHorizontalPlane, .existingPlane, .featurePoint])
        
        guard let closest = results?.first else {
            return
        }
        
        let transform = closest.worldTransform
        let anchor = ARAnchor(transform: transform)
        
        let child = makeText(with: transform, text: decodedMessage)
        userNodes[anchor] = child
        
        sceneView.session.add(anchor: anchor)
        
        
//        let child = makeSphere(with: transform)
//        print("position: \(child.position)")
        
        
        
        
    }

    func performQRCodeDetection(_ image: CIImage) ->  String {
        var decode = "QR Not Found"
        
        let detector: CIDetector = CIDetector(ofType: CIDetectorTypeQRCode, context: nil, options: [CIDetectorAccuracy: CIDetectorAccuracyHigh])!
        let features = detector.features(in: image)
        for feature in features as! [CIQRCodeFeature] {
            decode = feature.messageString!
        }
        
        return decode
    }
    
    private func makeText( with transform: matrix_float4x4, text: String) -> SCNNode {
        let textNode = SCNText(string: text, extrusionDepth: 1)
        textNode.flatness = 0
        
        let material = SCNMaterial()
        material.isDoubleSided = true
        material.normal.contents = UIColor.black
        material.diffuse.contents = UIColor.black
        material.specular.contents = UIColor.black
        textNode.materials = [material]
        
        let node = SCNNode(geometry: textNode)

        node.scale = .init(0.1, 0.1, 0.1)
        node.position = SCNVector3Make(transform.columns.3.x, transform.columns.3.y, transform.columns.3.z)
//        node.rotation = SCNVector4Make(0, 0, 0, -Float.pi/2)
//        node.transform = SCNMatrix4MakeRotation(-Float.pi/2, 1, 0, 0)
//        node.transform = SCNMatrix4MakeTranslation(transform.columns.3.x, transform.columns.3.y - 0.5, transform.columns.3.z)
        node.physicsBody = SCNPhysicsBody(type: .static, shape: SCNPhysicsShape(geometry: textNode, options: [:]))
        
        return node
    }
    
//    private func makeText( with transform: matrix_float4x4, text: String) -> SCNNode {
//        let textNode = SCNText(string: text, extrusionDepth: 1)
//        textNode.flatness = 0
//
//        let material = SCNMaterial()
//        material.isDoubleSided = true
//        material.normal.contents = UIColor.black
//        material.diffuse.contents = UIColor.black
//        material.specular.contents = UIColor.black
//        material.isDoubleSided = true
//        textNode.materials = [material]
//
//        let node = SCNNode(geometry: textNode)
//
//        node.transform = SCNMatrix4MakeTranslation(transform.columns.3.x, transform.columns.3.y, transform.columns.3.z)
//        node.scale = .init(0.1, 0.1, 0.1)
////        node.position = .init(0, 0.1, 0)
//        node.physicsBody = SCNPhysicsBody(type: .static, shape: SCNPhysicsShape(geometry: textNode, options: [:]))
//
//        return node
//    }
    
    
//    let text = SCNText(string: item.label, extrusionDepth: 5.0)
//    text.firstMaterial?.diffuse.contents = UIColor.orange
//    text.firstMaterial?.specular.contents = UIColor.orange
//    text.font = UIFont(name: "Optima", size: 100)
//    text.containerFrame = CGRect(x: 0, y: 0, width: 100, height: 44)
//
//    let textNode = SCNNode(geometry: text)
//    textNode.position = SCNVector3(-0.2 + x, -0.9 + delta, -1)
//
//
//    x += 0.12
    
    
//    scene.rootNode.addChildNode(textNode)
    
    private func makeSphere( with transform: matrix_float4x4) -> SCNNode {
        let sphere = SCNSphere(radius: 0.01)
        let node = SCNNode(geometry: sphere)
        node.transform = SCNMatrix4MakeTranslation(transform.columns.3.x, transform.columns.3.y + 0.5, transform.columns.3.z)
        node.physicsBody = SCNPhysicsBody(type: .dynamic, shape: SCNPhysicsShape(geometry: sphere, options: [:]))
        return node
    }
    
}

